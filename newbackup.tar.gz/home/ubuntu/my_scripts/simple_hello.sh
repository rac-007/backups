#!/bin/bash

echo "Hello, this is to test cronjob"
