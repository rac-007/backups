#!/bin/bash

# source file path
src=/home/ubuntu/my_scripts

#target file path
tgt=/home/ubuntu/backups


#compressing files
tar -czvf $tgt/$1.tar.gz $src


# displaying message
echo "backup complete"


