#!/bin/bash

for filename in $1/*
do       	
echo $filename
done
