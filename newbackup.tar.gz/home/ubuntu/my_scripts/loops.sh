#!/bin/bash


for num in {1..10}
do
echo "$num"
done
