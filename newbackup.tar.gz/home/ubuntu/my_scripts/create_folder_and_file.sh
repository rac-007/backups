#!/bin/bash
mkdir devops
cd /home/ubuntu/my_scripts/devops
touch my_file.txt
echo "I am learning how to write a script!" > my_file.txt
