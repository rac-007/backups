#!/bin/bash
echo "Linux has 8 types of script"
echo "Here we are using Bourne Again Shell"
echo "Next check the permissions on this bash script file"
echo "Thanks for reading this!"
