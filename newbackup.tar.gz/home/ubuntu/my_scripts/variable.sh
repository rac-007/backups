#!/bin/bash

echo "Welcome $@"

name="Rachana"
echo "My name is $name"

echo "Please enter your name:"
read username

echo "Please enter your roll no.:"
read rollno

echo "The name is: $username" 
echo "The Roll number is:$rollno"
echo "Congratulations!You passed the exam."

./my-first-script.sh
